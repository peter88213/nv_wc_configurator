"""Plugin template for novelibre.

Requires Python 3.7+
Copyright (c) Peter Triesberger
For further information see https://github.com/peter88213/nv_wc_configurator
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
from pathlib import Path
import webbrowser

import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_wc_configurator',
        LOCALE_PATH,
        languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message

from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

import tkinter as tk


class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon


class Plugin(PluginBase):
    VERSION = '0.1.0'
    API_VERSION = '5.50'
    DESCRIPTION = 'Word counter configurator'
    URL = 'https://github.com/peter88213/nv_wc_configurator'

    HELP_URL = 'https://github.com/peter88213/nv_wc_configurator/tree/main/docs/nv_wc_configurator'

    INI_FILENAME = 'wcconfig.ini'
    INI_FILEPATH = '.novx/config'
    SETTINGS = dict(
        additional_word_separators='—–',
        additional_chars_to_ignore='',
    )
    OPTIONS = {}

    def install(self, model, view, controller):
        """Install the plugin.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        super().install(model, view, controller)


        label = _('nv_wc_configurator Online help')
        self._ui.helpMenu.add_command(
            label=label,
            command=self.open_help,
        )

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/{self.INI_FILEPATH}'
        except:
            configDir = '.'
        self.iniFile = f'{configDir}/{self.INI_FILENAME}'
        self.configuration = self._mdl.nvService.new_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS,
        )
        self.configuration.read(self.iniFile)
        self._prefs = {}
        self._prefs.update(self.configuration.settings)
        self._prefs.update(self.configuration.options)

        self._wordCounter = self._mdl.nvService.get_word_counter()
        self.configure_word_counter()

    def configure_word_counter(self):
        try:
            self._wordCounter.set_ignore_regex(
                self._prefs['additional_chars_to_ignore']
            )
            self._wordCounter.set_separator_regex(
                self._prefs['additional_word_separators']
            )
        except AttributeError:
            pass

    def on_quit(self):
        """Write back the configuration file.
        
        Overrides the superclass method.
        """

        for keyword in self._prefs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self._prefs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self._prefs[keyword]
        self.configuration.write(self.iniFile)

    def open_help(self):
        webbrowser.open(self.HELP_URL)

